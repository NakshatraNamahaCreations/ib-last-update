import React from "react";

function ProductControl() {
  return <div>ProductControl</div>;
}

export default ProductControl;
